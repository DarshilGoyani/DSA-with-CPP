#include<iostream>
using namespace std;
main(){
    cout << "--------" <<endl;
    cout << "|\t|" <<endl;
    cout << "R\t|" <<endl;
    cout << "N\t|" <<endl;
    cout << "w\t|" <<endl;
    cout << "|\t|" <<endl;
    cout << "--------" <<endl;
}