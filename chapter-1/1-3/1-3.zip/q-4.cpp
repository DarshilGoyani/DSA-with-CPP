#include<iostream>
using namespace std;
main(){
    cout << "*" <<endl;
    cout << "*" <<endl;
    cout << "*" <<endl;
    cout << "* \t  *  * \t\t * " <<endl;
    cout << "*       *      *       *" <<endl;
    cout << "*     * \t *   *" <<endl;
    cout << "*   * \t\t   *" <<endl;
    cout << "* * " <<endl;
    cout << "*" <<endl;
}