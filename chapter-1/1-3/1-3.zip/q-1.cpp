#include<iostream>
using namespace std;
main(){
    cout << "Name \t : Darshil Goyani" <<endl;
    cout << "Age \t : 19" <<endl;
    cout << "School \t : Ashadeep IIT" <<endl;
    
}