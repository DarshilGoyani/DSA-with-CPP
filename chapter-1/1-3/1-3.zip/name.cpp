#include<iostream>
using namespace std;
main(){
    cout << "* * * * * \t\t         * \t\t\t * * * * \t\t * * * * * * \t\t * \t   * \t\t* * * * * * * \t\t *" <<endl;
    cout << "* \t  * \t\t        * * \t\t\t *\t* \t\t* \t\t \t * \t   *\t\t      * \t\t *" <<endl;
    cout << "* \t    * \t\t       *   * \t\t\t *\t *\t       * \t\t \t * \t   *\t\t      * \t\t *" <<endl;
    cout << "* \t     * \t\t      *     * \t\t\t *\t*\t\t* \t\t \t * \t   *\t\t      * \t\t *" <<endl;
    cout << "* \t     * \t\t     *\t     * \t\t\t * * * * \t\t  * * * * * \t\t * * * * * *\t\t      * \t\t *" <<endl;
    cout << "* \t     * \t\t    *\t      * \t\t *     * \t\t\t   * \t\t * \t   *\t\t      * \t\t *" <<endl;
    cout << "* \t    * \t\t   * * * * * * * \t\t *\t* \t\t\t    * \t\t * \t   *\t\t      * \t\t *" <<endl;
    cout << "* \t  * \t\t  * \t\t* \t\t *\t * \t\t\t   * \t\t * \t   *\t\t      * \t\t *" <<endl;
    cout << "* * * * * \t\t * \t\t * \t\t * \t  * \t\t* * * * * *  \t\t * \t   * \t\t* * * * * * * \t\t * * * * * * *" <<endl;
}